#include<stdio.h>
#include<fields.h>

int main()
{
  IS ptr;
  int nf, i;

  ptr = new_inputstruct("data.txt");
  nf = get_line(ptr);
  nf = get_line(ptr);
  for(i = 0; i < nf; i++)
    printf("%s\n", ptr->fields[i]);
  jettison_inputstruct(ptr);
  return 0;
}
