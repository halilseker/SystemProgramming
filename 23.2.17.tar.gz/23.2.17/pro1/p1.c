#include<stdio.h>
#include<string.h>
#include"fields.h"

int main()
{
  IS ptr;
  int nf, i, flag;

  ptr = new_inputstruct("data.txt");
  flag = 0;
  while((nf = get_line(ptr)) != -1){
    for(i = 0; i < nf; i++) 
      if(strcmp(ptr->fields[i], "software") == 0){
      	flag = 1;
	break; 
      }
    
    if(flag)
      break;
  }

  if(flag)
    printf("Line: %d,  column: %d\n", ptr->line, ++i);
  else
    printf("Not found\n");

  jettison_inputstruct(ptr);
  return 0;
}
