#include<stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main()
{
  int fd1, fd2;
  fd1  = open("data.txt", O_RDONLY);

  printf("fd = %d\n", fd1);
  
  fd2 = open("data.txt", O_RDONLY);

  printf("fd = %d\n", fd2);
  

  return 0;
}
