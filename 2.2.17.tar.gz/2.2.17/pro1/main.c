//

#include"my.h"

void foo1(int, int);
void foo2();

int a;

int main()
{

  a = 77;
  printf("We are in the MAIN a = %d\n", a);

  foo1(2, 3);
  foo2();

  printf("We are in the MAIN a = %d\n", a);
  return 0;
}
