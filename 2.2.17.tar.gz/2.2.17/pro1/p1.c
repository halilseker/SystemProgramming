//
#include"my.h"
void foo2();
int a;

void foo1(int a, int b)
{

  //a = 44;
  printf("foo1: before foo2 called a = %d\n", a);
  foo2();
  printf("foo1: after foo2 called a = %d\n", a);
}
