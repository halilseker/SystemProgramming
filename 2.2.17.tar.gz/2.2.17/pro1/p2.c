//
#include"my.h"

int a;

void foo2()
{
  a = 66;
  printf("1:foo2 a = %d\n", a);

  {
    int a = 99;
    printf("block: foo2 a = %d\n", a);
  }
  printf("2:foo2 a = %d\n", a);
}
