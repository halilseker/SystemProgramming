//

int main()
{
  int c, factor, value;

  factor = 5;
  value = 7;
  c = factor * value;

  return 0;
}
