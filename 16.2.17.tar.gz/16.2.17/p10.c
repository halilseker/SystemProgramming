#include <stdio.h>

struct Try {

  char b;
  char c;
  int i;

} t1;

int main(int argc, char **argv)
{
  int a = sizeof(t1);

  printf("Size = %d\n", a);
  return 0;
}

