#include <stdio.h>

int main(int argc, char **argv)
{
  char * s;
  int  array[2] = { 75000, 1000000};
  s = array;
  s++;
  printf("my array has %d hex 0x%x  and %d hex 0x%x\n",array[0], array[0], (int)(*s), (int)(*s));
  s++;
  printf("my array has %d hex 0x%x  and %d hex 0x%x\n",array[0], array[0], (int)(*s), (int)(*s));


  printf("array = %lx and s=%lx\n",array,s);

  return 0;
}
