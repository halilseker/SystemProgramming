#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int main(int argc, char **argv)
{
  char *s;

  s = (char *) malloc(10);
  strcpy(s, "Jim");
  printf("s = %s\n", s);

  return 0;
}
