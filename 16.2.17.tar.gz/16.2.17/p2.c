//
#include<stdio.h>
#include<stdlib.h>

int *f1(int len)
{
   int i;
   int *ptr;
   ptr = (int*) malloc (sizeof(int)*len);
   for (i = 0; i < len; i ++)
       ptr[i] = i;
   return ptr;
}
 
int main()
{
   int i, * array;
   //array = (int*) malloc (sizeof(int)*5);
   array = f1(5);
   for (i = 0; i < 5; i ++)
       printf("got value %d\n", array[i]);
   free(array);
   return 0;
}
