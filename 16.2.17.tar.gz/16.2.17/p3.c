//
#include<stdio.h>
 
int main()
{
int a, b, c, *ptr;
long d;
a = sizeof(a);
b = sizeof(ptr);
c = sizeof(d);
printf("int %d, ptr %d, long %d\n", a, b, c);

   return 0;
}
