#include <stdio.h>
#include <stdlib.h>



int main(int argc, char **argv)
{
  int i;
  char j[14];
  int *ptr;
  int *ip;
  char *jp;

  ptr = (int *) malloc(4);

  ip = &i;
  jp = j;

  printf("ip = 0x%x.  jp = 0x%x    ptr = 0x%x\n", ip, jp, ptr);

  return 0;
}
