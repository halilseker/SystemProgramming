#include <stdio.h>

int (*fptr)(int, int);

int sum(int, int);
int mul(int, int);

int main(int argc, char **argv)
{
  int res;

  fptr = sum;
  res = fptr(2,3);
  
  printf("Result = %d\n",res);

  fptr = mul;
  res = fptr(2,3);
  
  printf("Result = %d\n",res);


  return 0;
}


int sum(int a, int b)
{
  return (a+b);
}

int mul(int a, int b)
{
  return (a*b);
}
