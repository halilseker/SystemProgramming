//
#include<stdio.h>
#include<stdlib.h>

void f1(int * ptr, int len)
{
   int i;
   //   ptr = (int*) malloc (sizeof(int)*len);
   for (i = 0; i < len; i ++)
       ptr[i] = i;
}
 
int main()
{
   int i, * array;
   array = (int*) malloc (sizeof(int)*5);
   f1(array, 5);
   for (i = 0; i < 5; i ++)
       printf("got value %d\n", array[i]);
   free(array);
   return 0;
}
