#include <stdio.h>

char s1[15];

int main(int argc, char **argv)
{
  char s2[4] = "Jim";
  
  printf("s2 = %s\n", s2);

  //  s2 = "Jim"; 
  return 0;
}
